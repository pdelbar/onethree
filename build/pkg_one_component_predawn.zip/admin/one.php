<?php
  defined('_JEXEC') or die;

  $controller = JControllerLegacy::getInstance('One');

  $controller->execute(JFactory::getApplication()->input->get('task'));

  $controller->redirect();