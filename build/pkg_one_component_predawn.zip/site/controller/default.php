<?php
  /**
   * one|content for Joomla! 3.x (C) Paul Delbar 2015. Content is everything. Everything is content. 
   */

  defined('_JEXEC') or die('Restricted access');

  require_once JPATH_COMPONENT . DIRECTORY_SEPARATOR . 'dispatcher.php';

  class OneControllerDefault extends JControllerBase
  {
    public function execute()
    {
      $dispatcher = new OneDispatcherJoomla(JFactory::getApplication()->input->getArray());
      $dispatcher->dispatch();
      return true;
    }
  }